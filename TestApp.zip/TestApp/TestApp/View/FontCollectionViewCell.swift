//
//  FontCollectionViewCell.swift
//  TestApp
//
//  Created by raiyan sharif on 28/3/25.
//

import UIKit

class FontCollectionViewCell: UICollectionViewCell {

    @IBOutlet weak var fontName: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

}
