//
//  FontModel.swift
//  TestApp
//
//  Created by raiyan sharif on 28/3/25.
//

import Foundation

struct FontModel{
    var text: String
    var isPrimium: Bool
    
}
