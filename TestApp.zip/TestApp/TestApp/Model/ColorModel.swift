//
//  colorModel.swift
//  TestApp
//
//  Created by raiyan sharif on 28/3/25.
//

import UIKit

struct ColorModel{
    var color: UIColor
    var isPrimium: Bool
    
}
